//1. Analizar con find la colección
db.movies.find()

//2. Contar cuántos documentos (películas) tiene cargado
db.movies.find().count()

//3. Insertar una película
var nueva_pelicula = { "title": "Alberto", "year": 2000, "cast":[], "genres":[]}
db.movies.insertOne(nueva_pelicula)
db.movies.find()

var comprobacion = { "title": "Alberto" }
db.movies.find( comprobacion )

//4. Borrar la película insertada en el punto anterior (en el 3)
var borrar_película= { "title": "Alberto" }
db.movies.deleteOne(borrar_película)
db.movies.find(borrar_película)

var comprobacion2 = { "title": "Alberto" }
db.movies.find( comprobacion2 )

//5. Contar cuantas películas tienen actores (cast) que se llaman “and”
var contar= { "cast": "and" }
db.movies.find(contar).count()

//6. Actualizar los documentos cuyo actor (cast) tenga por error el valor “and” como si realmente fuera un actor. Para
//ello, se debe sacar únicamente ese valor del array cast. Por lo tanto, no se debe eliminar ni el documento (película) ni
//su array cast con el resto de actores.
var actualizar= { }
var operacion1= { $pull: { "cast": "and" } }
db.movies.updateMany(actualizar,operacion1)

comprobacion3= { "cast": "and" }
db.movies.find(comprobacion3)

//7. Contar cuantos documentos (películas) tienen el array ‘cast’ vacío
contar2={ cast: { $size: 0 } }
db.movies.count(contar2)

//8. Actualizar TODOS los documentos (películas) que tengan el array cast vacío, añadiendo un nuevo elemento dentro
//del array con valor Undefined
var actualizar2={cast: []}
var operacion2={$set: {cast: ["Undefined"]}}
db.movies.updateMany(actualizar2,operacion2 )

db.movies.find()

//9. Contar cuantos documentos (películas) tienen el array genres vacío
var contar3= {genres: []}
db.movies.find(contar3).count()

//10. Actualizar TODOS los documentos (películas) que tengan el array genres vacío, añadiendo un nuevo elemento
//dentro del array con valor Undefined
var actualizar3={genres: []}
var operacion3={$set: {genres: ["Undefined"]}}
db.movies.updateMany(actualizar3,operacion3 )

db.movies.find()

//11. Mostrar el año más reciente / actual que tenemos sobre todas las películas. 
db.movies.find({}).sort({ year: -1})

//12. Contar cuántas películas han salido en los últimos 20 años. Debe hacerse desde el último año que se tienen
//registradas películas en la colección, mostrando el resultado total de esos años
var query1={"year":{$gte:1998,$lte:2018}}
var fase1={$match:query1}
var query2={"_id":null,"total":{$sum:1}}
var fase2={$group:query2}
var etapas=[fase1,fase2]
db.movies.aggregate(etapas)

//13. Contar cuántas películas han salido en la década de los 60 (del 60 al 69 incluidos). Se debe hacer con el Framework
//de Agregación
db.movies.aggregate([
  // Filtro para obtener películas entre 60 y 69
  { $match: {year: { $gte: 1960, $lte: 1969 }} }).count()
  
//14. Mostrar el año u años con más películas mostrando el número de películas de ese año. Revisar si varios años
//pueden compartir tener el mayor número de películas
db.movies.aggregate([
    { $group: { _id: "$year", total_movies: { $sum: 1 } } },
    { $sort: { total_movies: -1 } },
    { $limit: 10 }
])

//15. Mostrar el año u años con menos películas mostrando el número de películas de ese año. Revisar si varios años
//pueden compartir tener el menor número de películas
db.movies.aggregate([
    { $group: { _id: "$year", total_movies: { $sum: 1 } } },
    { $sort: { total_movies: 1 } },
    { $limit: 9 }
])

//16. Guardar en nueva colección llamada “actors” realizando la fase $unwind por actor. Después, contar cuantos
//documentos existen en la nueva colección.
var etapa1 = {$unwind:'$cast'}
var etapa11 = {$project:{_id:0}}
var etapa111 = {$out:'actors'}
db.movies.aggregate([etapa1, etapa11, etapa111])

db.actors.find().count()

//17. Sobre actors (nueva colección), mostrar la lista con los 5 actores que han participado en más películas
//mostrando el número de películas en las que ha participado. Importante! Se necesita previamente filtrar para
//descartar aquellos actores llamados "Undefined". Aclarar que no se eliminan de la colección, sólo que filtramos
//para que no aparezcan.
var etapa2 = {$match:{cast:{$ne:'Undefined'}}}
var etapa22 = {$group:{_id:'$cast', cuenta:{$sum:1}}}
db.actors.aggregate([etapa2, etapa22]).sort({cuenta:-1}).limit(5)

db.actors.find()

//18. Sobre actors (nueva colección), agrupar por película y año mostrando las 5 en las que más actores hayan
//participado, mostrando el número total de actores.
var etapa3 = {$match:{cast:{$ne:'Undefined'}}}
var etapa33 = {$addFields:{cuenta:{$size:'$cast'}}}
var etapa333 = {$group:{_id:{title:'$title', year:'$year'}, cuenta:{$sum:'$cuenta'}}}
db.movies.aggregate([etapa3, etapa33, etapa333]).sort({cuenta:-1}).limit(5) 

//19. Sobre actors (nueva colección), mostrar los 5 actores cuya carrera haya sido la más larga. Para ello, se debe
//mostrar cuándo comenzó su carrera, cuándo finalizó y cuántos años ha trabajado. Importante! Se necesita previamente
//filtrar para descartar aquellos actores llamados "Undefined". Aclarar que no se eliminan de la colección, sólo que
//filtramos para que no aparezcan.

var query1={"cast":{$ne:"Undefined"}}
var fase1={$match:query1}
var fase2={$unwind: "$cast"}
var
query3={"_id":"$cast",comienza:{$min:"$year"},termina:{$max:"$year"}}
9
var fase3={$group:query3}
var subquery4={$subtract: ["$termina":"$comienza"]}
var query4={"años":subquery4}
var fase4={$addFields:query4}
var query5={"años":-1}
var fase5={$sort:query5}
var fase6={$limit:5}
var etapas=[fase1,fase2,fase3,fase4,fase5,fase6]
db.actors.aggregate(etapas)

//20. Sobre actors (nueva colección), Guardar en nueva colección llamada “genres” realizando la fase $unwind por
//genres. Después, contar cuantos documentos existen en la nueva colección
var etapa1 = {$unwind:'$genres'}
var etapa2 = {$project:{_id:0}}
var etapa3 = {$out:'genres'}
db.movies.aggregate([etapa1, etapa2, etapa3])

db.genres.find().count()

//21. Sobre genres (nueva colección), mostrar los 5 documentos agrupados por “Año y Género” que más número de
// películas diferentes tienen mostrando el número total de películas.
var etapa1 = {$match:{genres:{$ne:'Undefined'}}}
var etapa2 = {$group:{_id:{year:'$year', genres:'$genres'}, peliculas:{$addToSet:'$title'}}}
var etapa3 = {$project:{_id:1, peliculas:{$size:'$peliculas'}}}
db.genres.aggregate([etapa1, etapa2, etapa3]).sort({peliculas:-1}).limit(5)


//22. Sobre genres (nueva colección), mostrar los 5 actores y los géneros en los que han participado con más número de
//géneros diferentes, se debe mostrar el número de géneros diferentes que ha interpretado. Importante! Se necesita
//previamente filtrar para descartar aquellos actores llamados "Undefined". Aclarar que no se eliminan de la colección,
//sólo que filtramos para que no aparezcan

var query1 = {$match: {cast: {$ne: "Undefined"}}}
var fase1 = {$group: {"_id": "$cast", generos: {$addToSet: "$genres"}}}
var fase2 = {$project: {"_id":1, "numgeneros": {$size: "$generos"},
"generos": 1}} var phase3 = {$sort: {numgeneros: -1}}
var fase3 = {$limit: 5}
var etapas = [query1, fase1,fase2,fase3]
db.genres.aggregate(etapas)

//23. Sobre genres (nueva colección), mostrar las 5 películas y su año correspondiente en los que más géneros
// diferentes han sido catalogados, mostrando esos géneros y el número de géneros que contiene.

var etapa1 = {$match:{genres:{$ne:'Undefined'}}}
var etapa2 = {$group:{_id:{title:'$title', year:'$year'}, generos:{$addToSet:'$genres'}}}
var etapa3 = {$project:{_id:1, numgeneros:{$size:'$generos'}, generos:'$generos'}}
db.genres.aggregate([etapa1, etapa2, etapa3]).sort({numgeneros:-1}).limit(5)



